# Hazey Gen v1
This is a free twitch token gen skid = bad


# ・How to use
・Put proxies in proxies.txt: https://www.webshare.io/?referral_code=27rjvonmaef4

・2captcha key in config: https://2captcha.com?from=13246017

# ・About

・Leave all Suggestions in a pull request or issue

・It takes 2 seconds to star, longer to maintain :)

## ・Features
```
・Twitch token Generator

・Custom Usernames

・Custom Bio's
```

 ## 🥅 ・Goals

・ 10 Stars It's decent :D

・ 20  stars omg maybe some people actually seen it now

## Support me
・Join my discord
https://discord.gg/phts


## ・Skids
I will add all here, dm me with people


## 📄・License

This project is licensed under the GPL General Public License v3.0 License - see the [LICENSE.md](./LICENSE) file for details
```js
  ・Educational purpose only and all your consequences caused by you actions is your responsibility
  ・Selling this Free gen is forbidden
  ・If you make a copy of this/or fork it, it must be open-source and have credits linking to this repo
```


## 💭・ChangeLog

```diff
v1 ⋮ 17/6/22
+ Stable Release

v1.2 ⋮ 18/06/22
+ Fixed Json Decode Error

v2 ⋮ 08/08/22
+ Cleaned Up code
+ Got rid of useless methods

```



This is demonstrating that twitch have no security, educational use only!



